<?php

logg("Began of _afterChangeFiles", "INFO");

logg("End of _afterChangeFiles", "INFO");
return true;