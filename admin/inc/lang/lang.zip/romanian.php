<?php
/* TOP_COMMENT_START
 * Copyright (C) 2022, Champion Consulting, LLC  dba ChampionCMS - All Rights Reserved
 *
 * This file is part of Champion Core. It may be used by individuals or organizations generating less than $400,000 USD per year in revenue, free-of-charge. Individuals or organizations generating over $400,000 in annual revenue who continue to use Champion Core after 90 days for non-evaluation and non-development use must purchase a paid license. 
 *
 * Proprietary
 * You may modify this source code for internal use. Resale or redistribution is prohibited.
 *
 * You can get the latest version at: https://cms.championconsulting.com/
 *
 * Dated June 2023
 *
TOP_COMMENT_END */


// Lang "RO"
$lang_cancel = "Anulare";
$lang_duplicate = "Duplicare";
$lang_help = "Ajutor";
$lang_help_url ="https://help.championconsulting.com/";
$lang_settings = "Setari";
$lang_account = "Cont";
$lang_save = "Salveaza";
$lang_rename_btn = "Redenumeste";
$lang_title = "Champion CMS";

$lang_not_supported_in_this_version = 'Not supported in this version';

// Auto backup
$lang_autobackup_email_subject_line = "Notificare Champion auto-backup";
$lang_autobackup_email_text =<<<EOD
Buna,

Instalarea ta Champion a generat un fisier ZIP de backup.

Salutari,
Echipa Champion CMS
EOD;

// Breadcrumb
$lang_breadcrumb_home = 'Pagina principala';

// Login
$lang_login_forgot_password = "Ti-ai uitat parola ?";
$lang_login_forgot_password_email_body =<<<EOD
	Buna,
	
	Parola ta Champion este PASSWORD
EOD;
$lang_login_forgot_password_email_subject_line = "Ti-ai uitat parola Champion?"; 
$lang_login_incorrect = "Parola ta nu este corecta!";
$lang_login_password = "Parola";
$lang_login_button = "Intra in cont";
$lang_nav_logout = "Iesire din cont";
$lang_login_otp = "Parola OTP";
$lang_login_welcome = "Buna!";
$lang_login_name = "Utilizator Champion";

$lang_login_forgot_password_message = 'Parola ta a fost resetata';

// Home
$lang_home_emptyfold = "Acest fisier este gol"; 
$lang_home_new = "Nou";
$lang_home_upload_button = "Incarcare";
$lang_home_preview = "Previzualizare";

// Navigation
$lang_nav_title = "Navigare";
$lang_nav_home = "Panou principal";
$lang_nav_blocks = "Blocuri";
$lang_nav_img = "Media";
$lang_nav_users = "Utilizatori";
$lang_nav_store = "Magazin";
$lang_nav_blog = "Blog";
$lang_nav_pages = "Pagini";
$lang_nav_stats = "Statistici";

// Navigation logged in bar
$lang_nav_logged_in_add_block     = 'Adauga bloc nou';
$lang_nav_logged_in_add_blog_post = 'Adauga postare de blog noua';
$lang_nav_logged_in_add_media     = 'Adauga media';
$lang_nav_logged_in_add_page      = 'Adauga pagina noua';

// Gallery
$lang_gal_alt_gallery = "eticheta alternativa (alt tag)";
$lang_gal_caption_gallery = "Introdu legatura aici";
$lang_gal_filename = "Nume fisier";
$lang_gal_dimensions = "Dimensiuni";
$lang_gal_size = "Marime";
$lang_gal_audio = "Audio";
$lang_gal_video = "Video";
$lang_gal_img = "IMG";
$lang_gal_link = "Link";
$lang_gallery_tool_tip = "Pentru a crea o galerie lightbox, creati un folder de imagini si utilzati eticheta embed.";
$lang_crop = 'Taie';
$lang_media_order = 'Ordoneaza';
$lang_media_replace = 'Substituie';

// Pages
$lang_pages_meta = "Meta";
$lang_pages_options = "Options";
$lang_pages_title = "Titlul paginii";
$lang_pages_description = "Descrierea paginii";
$lang_pages_css = 'Inline CSS';
$lang_pages_js = 'Inline JS';
$lang_pages_language = 'Limba';
$lang_pages_template = 'Sablon pagina(template)';

// Create
$lang_create_file_or_folder = 'Pagina noua';
$lang_create_file_or_folder_block = "Bloc Nou";
$lang_create_file_or_folder_blog  = "Blog Nou";
$lang_create_file_or_folder_page  = "Pagina Noua";
$lang_create_file_or_folder_media = "Media Nou";

$lang_create_item       = 'Item';
$lang_create_item_block = 'Obiect Bloc';
$lang_create_item_blog  = 'Obiect Blog';
$lang_create_item_page  = 'Page';
$lang_create_item_media = 'Obiect Media';
$lang_create_item_folder = 'Folder';
$lang_create_button = "Creaza"; 
$lang_create_tool_tip = "Paginile, blocurile si postarile de blog trebuie incheiate cu '.txt', ce va fi automat adaugat. Pentru a crea un folder sau un blog nou, selectati Folder sau Blog si Creati.";
$lang_create_embed = "Embed";
$lang_create_embed_tag = "Embed Tag";
$lang_create_embed_url = "Embed URL:";
$lang_create_embed_html = "Embed HTML:";
$lang_create_embed_php = "Embed PHP:";
$lang_create_block_move = "Muta blocul la";
$lang_create_media_move = "Muta media la";
$lang_create_folder_error        = 'Nu a fost posibila crearea unui folder nou';
$lang_create_folder_error_exists = 'Folderul nou exista deja';
$lang_create_folder_error_no_base   = 'Nici un folder sursa nu a fost gasit';
$lang_create_folder_error_no_folder = 'Nici un nume nu a fost introdus pentru folder';

// Delete
$lang_delete = 'Sunteti sigur ca doriti sa stergeti';
$lang_del_button = "Sterge";

// Errors
$lang_error_create_ext = 'Extensia fisierului nu este valida.';
$lang_error_file_exists = 'Un fisier cu acest nume exista deja in acest folder .';
$lang_error_upload = 'Trebuie sa fi intr-o Galerie pentru a incarca o imagine.';
$lang_no_content = 'niciun continut nu a fost gasit';

//Blog
$lang_blog_title = 'Titlul Blogului';
$lang_blog_date = 'Data';
$lang_blog_read_more = 'Citeste mai mult';
$lang_blog_back_button = 'Inapoi';
$lang_blog_older = 'Mai vechi';
$lang_blog_newer = 'Mai noi';
$lang_blog_posted_in = 'Postat în:';
$lang_blog_error_folder = "Nu poti crea un folder in Blog";
$lang_blog_tool_tip = "Intrarile de blog sunt ordonate dupa numar, cel mai mare numar reprezentand postarea cea mai noua.";
$lang_blog_import = 'Import';
$lang_blog_import_tool_tip = 'Importa intrari de blog din RSS. Importatorul va importa din formaturile RSS si ATOM.';
$lang_blog_import_page_max = 'Numar maxi de pagini';
$lang_blog_import_page_var = 'Numele variabilei de paginare';
$lang_blog_import_url = 'URL';

$lang_blog_description = 'Descrierea blogului';
$lang_blog_featured_image = 'Blog Imagine recomandată';
$lang_blog_tags = 'Etichetele Blogului (tags,separate prin virgula)';
$lang_blog_tags_short = 'Etichetele Blogului';
$lang_blog_url = 'URL-ul Blogului';
$lang_blog_index = 'Doriti sa fie indexat?';
$lang_blog_nofollow = 'Doriti ca acesta sa fie "nu urmariti?"';
$lang_blog_custom = 'Descriere META personalizata';
$lang_blog_list = 'Lista de bloguri';

// Form
$lang_form_error1 = 'Va rugam completati campul ';
$lang_form_error2a = 'Campul dumneavoastra ';
$lang_form_error2b = ' este prea lung.';
$lang_form_subject_line = 'Contact';
$lang_form_email_sent = 'Email-ul a fost trimis';
$lang_form_sent_button = 'Trimite';
$lang_auto_thank_contact = 'Iti multumesc pentru email - acesta a fost primit si vom raspunde in curand';

$lang_form_error_recapcha = 'reCAPTCHA a eșuat';

$lang_form_comment = 'Cometariu';
$lang_form_gdpr    = 'GDPR';
$lang_form_phone   = 'Telefon';
$lang_form_name    = 'Nume';
$lang_form_email   = 'E-mail';

// Mailchimp
$lang_mailchimp_subscribe_label = 'Abonați-vă la lista noastră de difuzare';
$lang_mailchimp_email_address   = 'Adresa de email';
$lang_mailchimp_subscribe       = 'Abonati-va';

//Newsletter Form
$lang_newsletter_thanks ='Multumim!';
$lang_newsletter_try_again ='Incearca din nou';
$lang_newsletter_placeholder ='Introdu Email';
$lang_newsletter_send ='Inscrie-te';

// Redactor
$lang_redactor_mail_button     = 'Adauga o adresa de Email';
$lang_redactor_mail_link_title = 'Trimite email catre mine';

// Stats
$lang_stats_today = "Vizitatori";
$lang_stats_refers = "Topul referentilor";
$lang_stats_pages = "Topul paginilor";
$lang_stats_refresh = "Refresh";
$lang_stats_pageviews = "Vizualizari pagina";
$lang_stats_per_visit = "Pagini / Vizita";
$lang_stats_bounce_rate ="Rata de respingere";
$lang_stats_online = "Online";
$lang_stats_thisweek = "Aceasta saptamana";
$lang_stats_todays_stats = "Azi";
$lang_stats_nodata = "Nu exista date";
$lang_stats_browsers  = "browsere";
$lang_stats_countries = "tari";
$lang_stats_devices   = "dispozitive";
$lang_stats_systems   = "sisteme";

// Sweet Alert
$lang_sweetalert_ok    = "OK";
$lang_sweetalert_saved = "Salvat";

// Custom post types
$lang_custom_post_type_error_illegal_characters = 'Numele personalizat pentru postare contine caractere ilegale';
$lang_custom_post_type_error_illegal_name       = 'Numele personalizat pentru postare contine un nume ilegal';
$lang_custom_post_type_error_unknown_entry      = 'Acest tip de intrare pentru postare este necunoscut';

// Status messages
$lang_status_ok = 'Datele au fost salvate';

// Dashboard
$lang_dashboard_backups = 'Backupuri';
$lang_dashboard_blocks = 'Blocuri';
$lang_dashboard_edit_blocks = 'Editeaza Blocuri';
$lang_dashboard_blog = 'Blog';
$lang_dashboard_edit_blog = 'Editeaza Blog';
$lang_dashboard_notes = 'Notite Panou principal';
$lang_dashboard_file_storage = 'Stocarea fisierelor';
$lang_dashboard_media = 'Media';
$lang_dashboard_edit_media = 'Editeaza Media';
$lang_dashboard_pages = 'Pagini';
$lang_dashboard_edit_page = 'Editeaza Pagina';

// Settings
$lang_settings_title = 'Setari Champion';
$lang_settings_general = 'General';
$lang_settings_forms = 'Formulare';
$lang_settings_security = 'Securitate';
$lang_settings_permissions = 'Permisiuni';
$lang_settings_extend = 'Extinde';

//// Settings: General
$lang_settings_path = 'Cale';
$lang_settings_path_tooltip = 'Lasati necompletat daca este instalat in folderul radacina';
$lang_settings_admin = 'Admin';
$lang_settings_admin_tooltip = 'Nume folder pentru Admin';
$lang_settings_password = 'Parola';
$lang_settings_password_tooltip = 'Ceva greu de ghicit';
$lang_settings_backup_tooltip = 'Backup automat al siteului';
$lang_settings_backupemail = 'Backup pentru email';
$lang_settings_backupemail_tooltip = 'Locul in care se trimite backupul ZIP';
$lang_settings_time = 'Fus oras prestabilit(default)';
$lang_settings_language = 'Limba';
$lang_settings_ip = 'Anonimizare IP';
$lang_settings_frontpage = 'Afisarea paginii principale';
$lang_settings_adminfrontpage = 'Afisarea paginii principale de Admin';
$lang_settings_adminname = 'Nume utilizator Admin';
$lang_settings_adminname_tooltip = 'Folosit pentru a afisa numele pentru postari Blog';
$lang_settings_css = 'suprascriere CSS pentru tot siteul';
$lang_settings_css_tooltip = 'Copiati CSS aici';
$lang_settings_js = 'suprascriere JS pentru tot siteul';
$lang_settings_js_tooltip = 'Copiati JS aici';

$lang_settings_home_page = 'Pagina principala';

//// Settings: Avatar
$lang_settings_avatar_upload = 'încărcare avatar';

//// Settings: GDPR
$lang_settings_title_gdpr = 'GDPR';
$lang_settings_gdpr_enable_in_form = 'Activați GDPR în eticheta de formular';

$lang_settings_gdpr_enable_in_tag    = 'Activați GDPR în etichetă';
$lang_settings_gdpr_tag_text         = 'GDPR popup text';
$lang_settings_gdpr_tag_text_tooltip = 'GDPR popup text (tooltip)';

//// Settings: Cache
$lang_settings_title_cache = 'Cache';
$lang_settings_cache = 'Activati cache-ul frontend';

//// Settings: Editor
$lang_settings_title_editor = 'Editor';
$lang_settings_wysiwyg = 'Permite editorul WYSIWYG pe Blocuri (altfel HTML si Markdown)';
$lang_settings_upload = 'Fisierele permise pentru incarcare(upload)';
$lang_settings_upload_tooltip = 'Foloseste virgula pentru a separa extensiile pentru fisier';
$lang_settings_wysiwygpages = 'Permite editorul WYSIWYG pe Pagini (altfel HTML si Markdown)';
$lang_settings_integrate_rapidweaver = 'Integrează RapidWeaver';

//// Settings: Made in Champion
$lang_settings_title_made_in_champion = 'Creat in Champion';
$lang_settings_made_in_champion       = 'Insigna creat in champion adaugata';
$lang_settings_made_in_champion_label = 'Permite continut creat-in-champion pentru sablon';
$lang_settings_theme_meta_author_show       = 'Arata meta autorului in tema';
$lang_settings_theme_meta_author_show_label = 'Arata meta autorului in tema';

//// Settings: Media
$lang_settings_title_media = 'Media';
$lang_settings_jpeg = 'Calitate JPEG';
$lang_settings_jpeg_tooltip = 'Foloseste 100 pentru calitate maxima JPEG (fisiere mari)';
$lang_settings_jpegresample = 'Resampling JPEG "oprit"';
$lang_settings_jpegsize = 'calitate JPEG';
$lang_settings_jpegsize_tooltip = 'Scaleaza JPEGs la o dimensiune maxima in pixeli (inaltime)';
$lang_settings_thumbheight = 'Inaltime thumbnail';
$lang_settings_thumbheight_tooltip = 'Inaltime in px';
$lang_settings_thumb = 'Creati thumbnails';

//// Settings: Navigation
$lang_settings_title_navigation = 'Navigare';
$lang_settings_navigationmenu = 'Permiteti editarea frontend';
$lang_settings_title_managenavigation = 'Gestionati navigarea siteului';

// Open AI chatGPT
$lang_settings_title_openai_chatgpt     = 'OpenAI ChatGPT';
$lang_settings_openai_chatgpt_api_token = 'API token';

$lang_settings_title_stable_diffusion = 'Stable Diffusion';
$lang_settings_stable_diffusion_api_token = "API Token";

$lang_settings_ai_prompt = 'Prompt';
$lang_settings_ai_source = 'Source';

$lang_ai_image_message_no_api_token = 'Missing the API token';
$lang_ai_image_message_no_result    = 'No images have been generated';
$lang_ai_image_message_error        = 'An error has occurred when loading the generated image';

/// Settings: Google Analytics
$lang_settings_title_google = 'Google Analytics';
$lang_settings_google = 'Codul de urmarire Google Analytics';
$lang_settings_google_tooltip = 'Copiati codul dvs. de urmarire/monitorizare Google Analytics aici';

//// Settings: GeoIP
$lang_settings_title_geoip = 'GeoIP';
$lang_settings_geoip       = 'Date GeoIP pentru statistici despre site';
$lang_settings_geoip_label = 'Activeaza GeoIP pentru statistici aici';

$lang_settings_geoip_api_key         = 'GeoIP serviciu API KEY';
$lang_settings_geoip_api_key_tooltip = 'GeoIP serviciu API KEY';
$lang_settings_geoip_service         = 'GeoIP serviciu';
$lang_settings_geoip_service_tooltip = 'freegeoip, ipstack';

//// Settings: OGP
$lang_settings_title_ogp = 'OGP';
$lang_settings_ogp = 'Imagine OGP implicita';
$lang_settings_ogp_tooltip = 'Link relativ sau absolut';

$lang_settings_ogp_facebook_admin           = 'Facebook admins';
$lang_settings_ogp_facebook_admin_tooltip   = 'Facebook admins';
$lang_settings_ogp_facebook_id              = 'Facebook app ID';
$lang_settings_ogp_facebook_id_tooltip      = 'Facebook app ID';
$lang_settings_ogp_twitter_creator          = 'Cont Twitter personal';
$lang_settings_ogp_twitter_creator_tooltip  = 'Cont Twitter personal';
$lang_settings_ogp_twitter_username         = 'Contul Twitter pentru site-ul web';
$lang_settings_ogp_twitter_username_tooltip = 'Contul Twitter pentru site-ul web';

//// Settings: Blog
$lang_settings_title_blog = 'Blog';
$lang_settings_blogresults = 'Rezultate per pagina';
$lang_settings_blogresults_tooltip = 'Postari de tip Blog per pagina';
$lang_settings_blogdisqus = 'Permite comentarii Disqus';
$lang_settings_blogdisqususer = 'Nume utilizator Disqus';
$lang_settings_blogdisqususer_tooltip = 'Adaugati numele scurt aferent contului Disqus';
$lang_settings_blogdate = 'Fomatul datei';
$lang_settings_blogdate_tooltip = 'Format PHP al datei. Pentru mai multe detalii vedeti: https://php.net/manual/en/function.date.php';
$lang_settings_blog_flag_reverse = 'Inversă ordinea listei de bloguri'; 
$lang_settings_blogmasonry = 'Activeaza schema pt Blog de tip zidarie (masonry layout)';
$lang_settings_blog_blog_flag_show_link = 'Afișați linkul către conținutul blogului';
$lang_settings_blog_blog_flag_show_teaser_image = 'Afișează imaginea de previzualizare';

// Settings: import html page
$lang_import_html_button                   = 'Import HTML Page';
$lang_import_html_page_header              = 'Importing HTML';
$lang_import_html_page_no_input            = 'Enter URL or Text/Html';
$lang_import_html_page_url                 = 'URL';
$lang_import_html_page_success             = 'Page imported';
$lang_import_html_page_text                = 'Text/Html';

// Settings: export html
$lang_settings_export_html                 = 'Export HTML';
$lang_export_html_button                   = 'Export HTML Website';
$lang_export_html_settings_api_key         = 'API Key';
$lang_export_html_settings_api_key_tooltip = 'Key used for Export HTML API call';
$lang_export_html_settings_path            = 'Path';
$lang_export_html_settings_path_tooltip    = 'Files exported to this folder';

//// Settings: RSS
$lang_settings_title_rss = 'RSS';
$lang_settings_rsstitle = 'Titlul blogului RSS ';
$lang_settings_rsstitle_tooltip = 'Blogul meu';
$lang_settings_rssdescription = 'Descrierea RSS a blogului';
$lang_settings_rssdescription_tooltip = 'Acesta este blogul meu.';
$lang_settings_rssurl = 'Blog URL';
$lang_settings_rssurl_tooltip = 'http://example.com/blog';
$lang_settings_rsslang = 'Formatul datei';
$lang_settings_rsslang_tooltip = 'en-gb';
$lang_settings_rssurlprefix = ' Prefix Blog URL';
$lang_settings_rssurlprefix_tooltip = '(blog) ar fi blog-1-postare-titlu, de asemenea editati si in htaccess';

//// Settings: SMTP Settings
$lang_settings_title_smtp = 'Setari SMTP';
$lang_settings_smtpusername = 'Nume utilizator SMTP';
$lang_settings_smtpusername_tooltip = 'Completati doar daca doriti sa folositi SMTP';
$lang_settings_smtppassword = 'SMTP parola';
$lang_settings_smtppassword_tooltip = 'Parola';
$lang_settings_smtphost = 'SMTP host';
$lang_settings_smtphost_tooltip = 'mail.server.com';
$lang_settings_smtpport = 'SMTP port';
$lang_settings_smtpport_tooltip = '465';

//// Settings: SweetAlert
$lang_settings_title_sweetalert = 'Setari SweetAlert';
$lang_settings_sweetalert_active_tooltip  = 'Activeaza alertele';
$lang_settings_sweetalert_active          = 'Activeaza';
$lang_settings_sweetalert_timeout_tooltip = 'Timeout delay (milliseconds)';
$lang_settings_sweetalert_timeout         = 'Timeout';

//// Settings: Pagination
$lang_settings_title_pagination = 'Paginare';
$lang_settings_paginationlinks = 'Linkuri de pagina pentru afisare';
$lang_settings_paginationlinks_tooltip = 'Apare pe navigarea Blocurilor si Paginilor ca exemplu';
$lang_settings_paginationpages = 'Rezultate per pagina';
$lang_settings_paginationpages_tooltip = 'Cate pagini sa apara per link';

//// Settings: Forms
$lang_settings_forminputname = 'Introduceti numele';
$lang_settings_forminputname_tooltip = 'text';
$lang_settings_forminputemail = 'Introduceti emailul';
$lang_settings_forminputemail_tooltip = 'email';
$lang_settings_forminputtel = 'Introduceti telefonul';
$lang_settings_forminputtel_tooltip = 'text';
$lang_settings_formnamename = 'Textul pentru Nume';
$lang_settings_formnamename_tooltip = 'Nume';
$lang_settings_formemailname = 'Textul pentru Email';
$lang_settings_formemailname_tooltip = 'Email';
$lang_settings_formtextarea = 'Dimensiune textarea';
$lang_settings_formtextarea_tooltip = 'Numarul de randuri in comentariul textarea';
$lang_settings_formemail = 'Destinatarul formularului';
$lang_settings_formemail_tooltip = 'Separati multiplii destinatari prin virgula';
$lang_settings_formsubject = 'Linia de titlu a formularului';
$lang_settings_formsubject_tooltip = 'Ati primit un email';
$lang_settings_formthanks = 'Activeaza raspunsul automat de tip multumesc dupa inregistrare';
$lang_settings_formredirect = 'Redirectionarea inregistrarii';
$lang_settings_formredirect_tooltip = 'http://siteultau.com/multumiri';
$lang_settings_formcomment             = 'Text/Denumire pentru comentariu';
$lang_settings_formcommentname_tooltip = 'Comentariu';
$lang_settings_form_gdpr = 'GDPR intrare';
$lang_settings_form_gdpr_name_tooltip = 'GDPR';
$lang_settings_formphone               = 'Text/Denumire pentru telefon';
$lang_settings_formphonename_tooltip   = 'Telefon';

//// Settings: OTP One-Time Password
$lang_settings_title_otp = 'Setari OTP-parola dinamica (Admin)';
$lang_settings_otpactivate = 'Activeaza OTP (parola dinamica)';
$lang_settings_otpsecret = 'Secretul OTP (parola dinamica)';
$lang_settings_otpsecret_tooltip = 'Obtine de la o aplicatie OTP pt mobil, cum ar fi Google Authenticator';

//// Settings: reCAPTCHA
$lang_settings_title_recap = 'reCAPTCHA';
$lang_settings_recapkey = 'Cheia siteului reCAPTCHA ';
$lang_settings_recapkey_tooltip = 'Obtine de la contul Google: https://www.google.com/recaptcha';
$lang_settings_recapkeysecret = 'Cheia secreta reCAPTCHA ';
$lang_settings_recapkeysecret_tooltip = 'Obtine de la contul Google: https://www.google.com/recaptcha';

//// Settings: Permissions
$lang_settings_title_editor = 'Utilizator al Editorului';
$lang_settings_editor = 'Autorizeaza utilizatorul Editorului';
$lang_settings_editorpass = 'Parola pentru Editor';
$lang_settings_editorpass_tooltip = 'Ceva greu de ghicit';
$lang_settings_editoruser = 'Nume utilizator pentru Editor';
$lang_settings_editoruser_tooltip = 'Folosit pentru a afisa numele postarilor de tip Blog';
$lang_settings_title_editorotp = 'Setari OTP-parola dinamica (Editor)';
$lang_settings_editorotpactivate = 'Activeaza OTP (parola dinamica)';
$lang_settings_editorotpsecret = 'Secretul OTP (parola dinamica)';
$lang_settings_editorotpsecret_tooltip = 'Obtine de la o aplicatie OTP pt mobil, cum ar fi Google Authenticator';
$lang_settings_title_editoraccess = 'Permite Editorului sa acceseze oricare dintre (sau toate) aceste blocuri:';
$lang_settings_title_editorpagesaccess = 'Permite Editorului sa acceseze oricare dintre (sau toate) aceste pagini:';

//// Settings: Extend
$lang_settings_title_themes = 'Teme';
$lang_settings_themeselect = 'Tema selectata';
$lang_settings_themeupload = 'Incarca tema ZIP';
$lang_settings_title_plugins = 'Plugins';
$lang_settings_pluginupload = 'Incarca plugin ZIP';
$lang_settings_title_customposts = 'Tipuri de postari personalizate';
$lang_settings_managecustomposts = 'Gestioneaza tipurile de postari personalizate';
$lang_settings_themeuploader = 'Incarcati o noua tema ca fisier ZIP';
$lang_settings_pluginuploader = 'Incarcati un nou plugin ca fisier ZIP';

$lang_settings_title_debug_info  = 'Depanare';
$lang_settings_manage_debug_info = 'Depanare';
$lang_settings_manage_log_viewer = 'Vizualizator de jurnale';

$lang_settings_title_update  = 'Actualizați';
$lang_settings_manage_update = 'Actualizați';

//// Settings: Media
$lang_settings_mediaupload = 'Incarca un fisier media';
$lang_settings_upload_max_size = 'Dimensiunea maximă de încărcare';
$lang_settings_upload_size_error = 'Fișierul depășește dimensiunea maximă de încărcare';

//// Settings: Navigation
$lang_settings_navigationtitle = 'Gestioneaza linkurile de navigare';
$lang_settings_navigationsubtitle = 'Drag and drop pentru a reordona lista.';
$lang_settings_navigationsubmenu = 'Adauga sub-menu';
$lang_settings_navigation_non_champion_page = 'Adauga un obiect de tip non Champion';
$lang_settings_navigation_non_champion_name = 'Nume';
$lang_settings_navigation_non_champion_url  = 'URL';
$lang_settings_navigation_non_champion_open_in_new_tab = 'Open in new tab';
$lang_settings_navigation_activate = 'Activeaza';

$lang_settings_navigation_add_menu = "Adăugați meniul";
$lang_settings_navigation_menus = "Meniuri";

$lang_settings_navigation_up = 'Up';
$lang_settings_navigation_down = 'Down';

$lang_settings_navigation_expander_collapse = "Collapse";
$lang_settings_navigation_expander_expand   = "Expand";

$lang_settings_navigation_menu_all     = "Active Menu Items";
$lang_settings_navigation_menu_pending = "Inactive Menu Items";

$lang_settings_navigation_text = 'Drag the items into the order you prefer. To add pages to the menu, simply drag from "Inactive Menu Items" to "Active Menu Items"';

//// Settings: Custom Post Type
$lang_settings_custompostentries = 'Intrari de tip postare personalizata pentru:';
$lang_settings_custompostadd = 'Adauga o noua intrare';
$lang_settings_title_custompostedit = 'Intrari de tip postare personalizata pentru:';
$lang_settings_custompostback = '< Inapoi la pagina listei';
$lang_settings_custompostname = 'Numele Postarii';
$lang_settings_custompostdelete = 'intrare de tip postare personalizata';
$lang_settings_custompostaddentry = 'Adauga o intrare de tip postare personalizata pentru:';
$lang_settings_customposttypes = 'Tipul postarii personalizate';
$lang_settings_custompostmanage = 'gestioneaza intrarile';
$lang_settings_custompostmanageedit = 'editeaza';
$lang_settings_custompostmanageadd = 'Adauga un nou tip de postare personalizata';
$lang_settings_title_custompostedit_title = 'Editati tipul unei postari personalizate';
$lang_settings_title_custompostedit_titlein = 'Editati o intrare de tip postare personalizata in:';
$lang_settings_custompostdefadd = 'Adaugati un tip de postare personalizata';
$lang_settings_custompostdeftypename = 'Numele tipului de postare';
$lang_settings_custompostdefname = 'Nume';
$lang_settings_custompostdeftype = 'Tip';
$lang_settings_custompostdeffield = 'Camp';
$lang_settings_custompostcontent = 'Continut';

# log viewer
$lang_settings_log_viewer_log_files   = 'Fișierele jurnal';
$lang_settings_log_viewer_log_content = 'Intrările de jurnal'; 

// Tags
$lang_settings_title_tags = 'Etichete';
$lang_settings_manage_tags = 'Gestionati etichete';
$lang_settings_tags_title = 'Gestionati etichetele';
$lang_settings_tags_subtitle = 'Adauga / Sterge etichete si descrieri.';
$lang_settings_tags_name = 'Nume';
$lang_settings_tags_description = 'Descriere';

// Template Strings
$lang_settings_title_template_strings = 'Textul șablonului';

$lang_settings_template_string_admin_login_welcome_tooltip = 'Eticheta Span este evidențiată. Actual: Buna! Utilizator Champion';
$lang_settings_template_string_admin_login_welcome         = 'Autentificare Bun venit pe text';

# User Group List
$lang_settings_title_user_group_list  = 'Listă grupuri de utilizatori';
$lang_settings_manage_user_group_list = 'Gestionați lista de grupuri de utilizatori';

$lang_settings_user_group_list_title    = 'Gestionați grupurile';
$lang_settings_user_group_list_subtitle = 'Adăugați / ștergeți grupuri';

$lang_settings_user_group_list_group_name  = 'Numele Grupului';
$lang_settings_user_group_list_permissions = 'Permisiuni de acces';

$lang_settings_user_group_list_read       = 'Citit';
$lang_settings_user_group_list_read_write = 'Citeste, scrie';

$lang_settings_user_group_list_access_denied = 'Accesul la acest element este interzis';

// User List
$lang_settings_title_user_list = 'Lista de utilizatori';
$lang_settings_manage_user_list = 'Gestionați lista de utilizatori';

$lang_settings_user_list_title = 'Gestionare Utilizatori';
$lang_settings_user_list_subtitle = 'Adăugați / ștergeți utilizatorii';

$lang_settings_user_list_acl_role = 'Rolul utilizatorului';
$lang_settings_user_list_otp_activate = 'Activați OTP';
$lang_settings_user_list_password = 'Parola';
$lang_settings_user_list_username = 'Nume de utilizator';

$lang_settings_user_list_error_no_group = 'Adăugați un grup de utilizatori unui utilizator nou';

// Unishop
$lang_settings_unishop_title = 'Champion Comerţ';
$lang_settings_unishop_update = 'Gestionați-vă magazinul';
$lang_settings_integrate_ecommerce = 'Integrează comerțul';

// Search
$lang_search_title = 'Cauta';
$lang_search_placeholder = 'Termen de cautare';
$lang_search_cta = 'Cauta';
$lang_search_noresults = 'Niciun rezultat gasit';
$lang_search_results = 'Rezultatele cautarii';
$lang_search_links = 'Link catre';

// Page List
$lang_pagelist = 'Lista paginilor';

// Admin - Debug info
$lang_debug_info_title     = 'Depanare';
$lang_debug_info_path      = 'Cale';
$lang_debug_info_title_sub = 'Permisiuni de fișiere';
$lang_debug_info_button    = 'Descarca';
$lang_debug_info_text      = 'Descărcați fișierul zip';

// Admin - Open
$lang_open_meta_draft_mode = 'Mod de draft';
$lang_open_meta_searchable = 'Afișați în căutare';

// Admin - Update
$lang_update_title     = 'Actualizare Champion install';
$lang_update_title_sub = 'Încărcați fișierul Champion zip nou';
$lang_update_button    = 'Actualizați';

# Plugin & Tags Page
$lang_plugins_tags = (object)[
	'menu' => 'Plugin-urile ajută',
	'page' => (object)[
		'title' => 'Plugin-uri instalate',
		'plugin_title' => 'Plugin-uri',
		'tag_title' => 'Etichete',
		'default_description' => 'No information available for this item',
		'plugins' => (object)[
			'drop'           => 'Drag and drop plugin',
			'unishop'        => 'Store',
			'unishop_editor' => 'Edit Store data',
			'disqus'         => 'Commenting',
			'ogp'            => 'Social META Data',
			'parsedown'      => 'Markdown parser'
		],
		
		'tags' => (object)[
			'at' => 'Hide mail addresses (Redactor)',
			'block' => 'Show a block - {{block}}',
			'block_loop' => 'Show all blocks in a folder',
			'blog' => 'Show a blog - {{blog}}',
			'blog-content-loop' => 'Create your Blog layout - {{blog}} {{featured-image}} {{blog-content-loop}} {{blog-item-author}} {{blog-item-date}} {{blog-item-featured-image}} {{blog-item-title}} {{blog-item-content}} {{/blog-content-loop}} {{/blog}}',
			'blog-item-author' => 'Blog item author block',
			'blog-item-content' => 'Blog item content block',
			'blog-item-date' => 'Blog item date block',
			'blog-item-featured_image' => 'Blog item featured image',
			'blog-item-tag' => 'Blog item tags',
			'blog-item-title' => 'Blog item title block',
			'blog-list' => 'List Blog posts - {{blog-list}}',
			'blog-show' => 'Arrange Blog items in detail - {{blog-show}}',
			'blog-tags' => 'Show blog tags - {{blog-tags}}',
			'breadcrumb' => 'Show site breadcrumbs - {{breadcrumb}}',
			'cookieconsent' => 'Show consent to track cookies - {{cookieconsent:#000:#f1d600:edgeless:bottom:www.championcms.com}}',
			'custom_post_type' => 'Show a custom post type object - {{custom_post_type:book/hercules}}',
			'domain' => 'Show the current domain. Useful for links - {{domain}}',
			'dropzone' => 'Add a dropzone upload handler area - {{dropzone:media/gallery1}}',
			'email-list' => 'Collect emails - {{email-list}}',
			'endpoint' => 'Create a link to a block (Block embed option)',
			'featured-image' => 'Show featured image for a blog post',
			'form' => 'Contact form - {{form}}',
			'gal' => 'Gallery tag - {{gal:galname}} or {{gal:gallery1:5:yes}}',
			'gdpr' => 'Show GDPR tracking consent - {{gdpr:additional text}}',
			'googlemaps' => 'Google maps tag - {{googlemaps:address=brooklyn children museum-new york-usa,width=600,height=300,zoom=12}}',
			'justforms' => 'Just forms - {{justforms:formid:height}}',
			'link' => 'Directly lnk to a blog/page - {{link:page/animal/hippo}}    {{link:blog/1}}',
			'localizer' => 'Locale (translation) aware Blocks - {{localizer:block}}',
			'localizer_init' => 'Save locale in session',
			'mailchimp' => 'Email form via MailChimp API - {{mailchimp:user:formid}}',
			'masonry' => 'Gallery tag using masonry layout - {{masonry:galname}}',
			'media_player' => 'Show a media player for audio/video media - {{media_player://domain.com/content/media/CheersThemeTune.mp3:audio/mp3:audio}}    {{media_player://domain.com/content/media/rotate_set.mov:video/mp4:video:400:300}}',
			'navigation' => 'Navigation bar (Settings)',
			'navigation_logged_in' => 'Navigation bar for logged in users (Settings)',
			'ogp' => 'OGP - make sure to add the tag in the Template file',
			'page_list' => 'Show a list of pages - {{page_list}}',
			'paypal' => 'Paypal integration - {{paypal:email@domain.com:USD:site.com/success:site.com/cancel:Buy with:20:Polo Shirt}}',
			'picture' => 'Show an image from the media folder',
			'policy' => 'Show the privacy policy - {{policy:company:location:date}}',
			'recentposts' => 'Show blog recent posts - {{recentposts:"10":"blog/another"}}',
			'recentposts_visual' => 'Show blog recent posts with embedded images - {{recentposts_visual:"limit":"location":"no_date":"limit text"}}',
			'sb_block' => 'Allow code in a Block -  {{sb_block:name}}',
			'sb_localizer' => 'Locale specific SuperBlock - {{sb_localizer}}',
			'sb_login' => 'Control access to a page - {{sb_login:password:sharedsecret:blockname:errormessage}}',
			'search' => 'Show search form and data - {{search}}',
			'show_var' => 'Show a link path - {{show_var:path}} e.g. {{show_var:path}}/privacy as the link to your Privacy page',
			'slide' => 'Show a gallery as a slide show - {{slide:galname}}',
			'social' => 'Social share buttons - {{social}}',
			'stripe' => 'Stripe API integration - {{stripe:pk_live123456789:sku_123456789:site.com/success:site.com/cancel:Buy Now}} ',
			'social_exposure' => 'Show social media META images - place in media/opengraph directory',
			'teaser_image' => 'Show a blog teaser image - option in Settings',
			'theme_css' => 'Show page CSS - option in Settings',
			'theme_js' => 'Show page JS - option in Settings',
			'theme_js_body' => 'Show page JS (in body) - option in Settings',
			'thumbs' => 'Show media thumbnails - {{thumbs:galname}}',
			'unishop' => 'Display Store info - {{unishop:"test@this.that":"USD":"$":"US":"0":"/paypal_ok":"/paypal_cancel"}}'
		]
	]
];